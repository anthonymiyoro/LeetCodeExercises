

public class TestSleep extends multithreading.ThreadSleep {

    public static void main(String[] args){
        //    Initialise run function from ThreadSleep() class
        multithreading.ThreadSleep newSleep = new multithreading.ThreadSleep();
        newSleep.run();
        }

}
